﻿namespace WebApplicationAPP.Models
{
    public class CalculadoraViewModel
    {
        public double valor1 { get; set; }

        public double valor2 { get; set; }

        public double resultado { get; set; }

        public string operacion { get; set; }
        //?????
    }
}
